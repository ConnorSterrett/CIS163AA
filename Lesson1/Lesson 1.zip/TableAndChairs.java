/*
/Name: Connor Sterrett
/Date: 7/30/15
/Class: CIS163AA
/This class prints to the console an image of two chairs and a table
*/
public class TableAndChairs
{
	public static void main(String[] args)
	{
		//prints two chairs and a table one line at a time
		System.out.println("X                     X");
		System.out.println("X                     X");
		System.out.println("X      XXXXXXXXX      X");
		System.out.println("XXXXX  X       X  XXXXX");
		System.out.println("X   X  X       X  X   X");
		System.out.println("X   X  X       X  X   X");		
	}
}