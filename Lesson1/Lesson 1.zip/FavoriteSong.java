/*
/Name: Connor Sterrett
/Date: 7/30/15
/Class: CIS163AA
/This class prints lyrics from Pink Floyd's "Time" to the console
*/

public class FavoriteSong
{
	public static void main(String[] args)
	{
		//Prints some lines from Pink Floyd's "Time"
		System.out.println();  //blank line
		System.out.println("------------------------Pink Floyd - Time------------------------");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("Tired of lying in the sunshine staying home to watch the rain");
		System.out.println("You are young and life is long and there is time to kill today");
		System.out.println("And then one day you find ten years have got behind you");
		System.out.println("No one told you when to run, you missed the starting gun");
		System.out.println(); //blank line
		//Heart-wrenching guitar solo goes here
		System.out.println("So you run and you run to catch up with the sun but it's sinking");
		System.out.println("Racing around to come up behind you again");
		System.out.println("The sun is the same in a relative way but you're older,");
		System.out.println("Shorter of breath.  One day closer to death.");
		System.out.println("-----------------------------------------------------------------");
	}
}